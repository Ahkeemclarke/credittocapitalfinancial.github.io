export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: "var(--color-primary-50)",
          100: "var(--color-primary-100)",
          500: "var(--color-primary-500)",
          600: "var(--color-primary-600)",
          900: "var(--color-primary-900)",
          DEFAULT: "var(--color-primary)",
          foreground: "var(--color-primary-foreground)"
        },
        secondary: {
          DEFAULT: "var(--color-secondary)",
          foreground: "var(--color-secondary-foreground)"
        },
        accent: {
          DEFAULT: "var(--color-accent)",
          foreground: "var(--color-accent-foreground)"
        },
        success: {
          DEFAULT: "var(--color-success)",
          foreground: "var(--color-success-foreground)"
        },
        warning: {
          DEFAULT: "var(--color-warning)",
          foreground: "var(--color-warning-foreground)"
        },
        error: {
          DEFAULT: "var(--color-error)",
          foreground: "var(--color-error-foreground)"
        },
        info: {
          DEFAULT: "var(--color-info)",
          foreground: "var(--color-info-foreground)"
        },
        background: "var(--color-background)",
        foreground: "var(--color-foreground)",
        surface: {
          DEFAULT: "var(--color-surface)",
          foreground: "var(--color-surface-foreground)",
          elevated: "var(--color-surface-elevated)",
          glass: "var(--color-surface-glass)"
        },
        muted: {
          DEFAULT: "var(--color-muted)",
          foreground: "var(--color-muted-foreground)"
        },
        border: {
          DEFAULT: "var(--color-border)",
          strong: "var(--color-border-strong)"
        },
        input: "var(--color-input)",
        ring: "var(--color-ring)"
      },
      boxShadow: {
        glass: "var(--shadow-glass)",
        card: "var(--shadow-card)",
        'card-hover': "var(--shadow-card-hover)"
      },
      borderRadius: {
        card: "var(--radius-card)",
        button: "var(--radius-button)"
      }
    },
  },
  plugins: [],
  darkMode: 'media',
}