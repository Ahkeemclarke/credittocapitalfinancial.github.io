import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';

import { analyticsService } from './services/analyticsService';
// --- Constants & Config ---
const BASE_URL = import.meta.env.DEV ? '/api' : 'https://nicholasd6rmez.lastapp.dev';
const APP_ID = '48193611-0824-4c0e-98ec-b971e9a1bb13';

// --- Types ---
interface User {
  id: string;
  provider: string;
  created_at: string;
}

interface AssessmentResponse {
  question: string;
  answer: string;
  field_name: string;
}

interface ActionItem {
  priority: number;
  action: string;
  impact: string;
}

interface Assessment {
  id?: string;
  user_id: string;
  profile_type: string;
  responses: AssessmentResponse[];
  credit_score_range?: string | null;
  financial_health_score?: number | null;
  funding_readiness_score?: number | null;
  ai_guidance?: string | null;
  action_items?: ActionItem[] | null;
  completed: boolean;
}

interface AIResponse {
  credit_score_analysis: {
    range: string;
    category: string;
    gauge_percentage: number;
  };
  financial_health_summary: {
    overall_rating: string;
    debt_to_income_ratio: string;
    credit_utilization: string;
    savings_status: string;
    key_strengths: string[];
    areas_for_improvement: string[];
  };
  ai_guidance: {
    primary_recommendation: string;
    secondary_recommendations: string[];
  };
  funding_readiness: {
    readiness_score: number;
    readiness_level: string;
    improvement_areas: string[];
  };
  action_items: ActionItem[];
  educational_resources: {
    title: string;
    topic: string;
    relevance: string;
  }[];
}

// --- API Helpers ---
const api = {
  createUser: async (): Promise<User> => {
    const res = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'users',
        data: { provider: 'anonymous' }
      })
    });
    if (!res.ok) throw new Error('Failed to create user');
    return res.json();
  },
  createAssessment: async (data: Assessment): Promise<Assessment> => {
    const res = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'assessments',
        data
      })
    });
    if (!res.ok) throw new Error('Failed to create assessment');
    return res.json();
  },
  updateAssessment: async (data: Assessment): Promise<Assessment> => {
    const res = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'assessments',
        data
      })
    });
    if (!res.ok) throw new Error('Failed to update assessment');
    return res.json();
  },
  getAIGuidance: async (query: string): Promise<AIResponse> => {
    const formData = new URLSearchParams();
    formData.append('app_id', APP_ID);
    formData.append('query', query);

    const res = await fetch(`${BASE_URL}/aiapi/answertext`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: formData.toString()
    });
    if (!res.ok) throw new Error('Failed to get AI guidance');
    return res.json();
  }
};

// --- Components ---

// 1. Splash Screen
const SplashScreen: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/assessment');
    }, 3000);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-surface to-surface-elevated dark:from-gray-900 dark:to-gray-800 p-4 cursor-pointer" onClick={() => navigate('/assessment')}>
      <div className="animate-fade-in flex flex-col items-center text-center">
        <div className="w-24 h-24 mb-6 rounded-full bg-primary/10 dark:bg-primary/20 flex items-center justify-center shadow-glass">
          <i className="fa fa-building text-4xl text-primary dark:text-primary-400"></i>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-foreground dark:text-white mb-4 tracking-tight">
          Credit to <span className="text-warning dark:text-warning-500">Capital</span>
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground dark:text-gray-300 max-w-md animate-slide-up" style={{ animationDelay: '0.2s' }}>
          <i className="fa fa-quote-left text-sm mr-2 opacity-50"></i>
          Build Knowledge. Prepare for Capital.
        </p>
      </div>
    </div>
  );
};

// 2. Main Assessment Screen
const QUESTIONS = [
  {
    id: 'profile_type',
    title: 'What is your primary profile type?',
    description: 'Select the path that best describes your current focus.',
    type: 'toggle',
    options: ['Personal Credit', 'Business Credit']
  },
  {
    id: 'credit_score_range',
    title: 'What is your estimated current credit score range?',
    description: 'This helps us understand your starting point.',
    type: 'select',
    options: ['Below 580', '580-620', '621-670', '671-739', '740+']
  },
  {
    id: 'annual_income',
    title: 'What is your approximate annual income?',
    description: 'Used to calculate debt-to-income ratios.',
    type: 'number',
    placeholder: 'e.g. 55000'
  },
  {
    id: 'credit_card_debt',
    title: 'What is your total outstanding credit card debt?',
    description: 'Include all revolving credit accounts.',
    type: 'number',
    placeholder: 'e.g. 15000'
  },
  {
    id: 'emergency_fund_status',
    title: 'Do you have an emergency fund?',
    description: 'Lenders look for financial stability.',
    type: 'select',
    options: ['No emergency fund', 'Yes, but limited (1-2 months)', 'Yes, adequate (3-6 months)', 'Yes, excellent (6+ months)']
  }
];

const AssessmentScreen: React.FC<{ userId: string }> = ({ userId }) => {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [responses, setResponses] = useState<Record<string, string>>({
    profile_type: 'Personal Credit'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentQuestion = QUESTIONS[currentIndex];
  const progress = ((currentIndex) / QUESTIONS.length) * 100;

  const handleNext = async () => {
    if (currentIndex < QUESTIONS.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      await submitAssessment();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const submitAssessment = async () => {
    setIsSubmitting(true);
    try {
      // 1. Format responses
      const formattedResponses: AssessmentResponse[] = QUESTIONS.map(q => ({
        question: q.title,
        answer: responses[q.id] || '',
        field_name: q.id
      }));

      // 2. Create initial assessment
      const initialAssessment: Assessment = {
        user_id: userId,
        profile_type: responses.profile_type,
        responses: formattedResponses,
        completed: false
      };
      const created = await api.createAssessment(initialAssessment);

      // 3. Get AI Guidance
      const query = `Analyze this financial profile: ${JSON.stringify(formattedResponses)}`;
      const aiResult = await api.getAIGuidance(query);

      // 4. Update assessment with AI results
      const updatedAssessment: Assessment = {
        ...created,
        credit_score_range: aiResult.credit_score_analysis.range,
        financial_health_score: aiResult.financial_health_summary.gauge_percentage || 50,
        funding_readiness_score: aiResult.funding_readiness.readiness_score,
        ai_guidance: aiResult.ai_guidance.primary_recommendation,
        action_items: aiResult.action_items,
        completed: true
      };
      
      const finalAssessment = await api.updateAssessment(updatedAssessment);
      
      // 5. Navigate to results
      navigate('/results', { state: { assessment: finalAssessment, aiData: aiResult } });
    } catch (error) {
      console.error('Error submitting assessment:', error);
      alert('There was an error processing your assessment. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background dark:bg-gray-950 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-surface/80 dark:bg-gray-900/80 border-b border-border dark:border-gray-800 px-4 py-4">
        <div className="max-w-screen-xl mx-auto flex items-center justify-between">
          <div className="font-bold text-lg text-foreground dark:text-white flex items-center gap-2">
            <i className="fa fa-building text-primary dark:text-primary-400"></i>
            <span>Credit to <span className="text-warning dark:text-warning-500">Capital</span></span>
          </div>
          <div className="text-sm text-muted-foreground dark:text-gray-400 font-medium">
            Step {currentIndex + 1} of {QUESTIONS.length}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-2xl">
          {/* Progress Bar */}
          <div className="w-full bg-muted dark:bg-gray-800 rounded-full h-2 mb-8 overflow-hidden">
            <div 
              className="bg-primary dark:bg-primary-500 h-2 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            ></div>
          </div>

          {/* Question Card */}
          <div className="bg-surface dark:bg-gray-900 rounded-card shadow-card dark:shadow-none border border-border dark:border-gray-800 p-6 md:p-10 animate-fade-in">
            <div className="mb-8 text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 dark:bg-primary/20 text-primary dark:text-primary-400 mb-4">
                <i className={`fa ${currentQuestion.type === 'toggle' ? 'fa-user-circle' : currentQuestion.type === 'number' ? 'fa-keyboard' : 'fa-list'} text-xl`}></i>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground dark:text-white mb-2">
                {currentQuestion.title}
              </h2>
              <p className="text-muted-foreground dark:text-gray-400">
                {currentQuestion.description}
              </p>
            </div>

            {/* Input Area */}
            <div className="mb-10">
              {currentQuestion.type === 'toggle' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {currentQuestion.options?.map(opt => (
                    <button
                      key={opt}
                      onClick={() => setResponses({ ...responses, [currentQuestion.id]: opt })}
                      className={`p-4 rounded-xl border-2 transition-all duration-200 flex flex-col items-center gap-2 ${
                        responses[currentQuestion.id] === opt 
                          ? 'border-primary dark:border-primary-500 bg-primary/5 dark:bg-primary/10 text-primary dark:text-primary-400' 
                          : 'border-border dark:border-gray-700 bg-surface dark:bg-gray-800 text-foreground dark:text-gray-300 hover:border-primary/50 dark:hover:border-primary-500/50'
                      }`}
                    >
                      <i className={`fa ${opt.includes('Business') ? 'fa-briefcase' : 'fa-user'} text-2xl mb-1`}></i>
                      <span className="font-semibold">{opt}</span>
                    </button>
                  ))}
                </div>
              )}

              {currentQuestion.type === 'select' && (
                <div className="space-y-3">
                  {currentQuestion.options?.map(opt => (
                    <button
                      key={opt}
                      onClick={() => setResponses({ ...responses, [currentQuestion.id]: opt })}
                      className={`w-full p-4 rounded-xl border text-left transition-all duration-200 flex items-center justify-between ${
                        responses[currentQuestion.id] === opt 
                          ? 'border-primary dark:border-primary-500 bg-primary/5 dark:bg-primary/10 text-primary dark:text-primary-400 font-medium' 
                          : 'border-border dark:border-gray-700 bg-surface dark:bg-gray-800 text-foreground dark:text-gray-300 hover:bg-muted dark:hover:bg-gray-700'
                      }`}
                    >
                      <span>{opt}</span>
                      {responses[currentQuestion.id] === opt && <i className="fa fa-check-circle"></i>}
                    </button>
                  ))}
                </div>
              )}

              {currentQuestion.type === 'number' && (
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground dark:text-gray-400 font-medium">$</span>
                  <input
                    type="number"
                    value={responses[currentQuestion.id] || ''}
                    onChange={(e) => setResponses({ ...responses, [currentQuestion.id]: e.target.value })}
                    placeholder={currentQuestion.placeholder}
                    className="w-full pl-8 pr-4 py-4 rounded-xl border border-border dark:border-gray-700 bg-input dark:bg-gray-800 text-foreground dark:text-white text-lg focus:outline-none focus:ring-2 focus:ring-primary dark:focus:ring-primary-500 transition-all"
                  />
                </div>
              )}
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-border dark:border-gray-800">
              <button
                onClick={handlePrev}
                disabled={currentIndex === 0 || isSubmitting}
                className="px-6 py-3 rounded-button font-medium text-muted-foreground dark:text-gray-400 hover:text-foreground dark:hover:text-white hover:bg-muted dark:hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <i className="fa fa-arrow-left"></i> Back
              </button>
              
              <button
                onClick={handleNext}
                disabled={!responses[currentQuestion.id] || isSubmitting}
                className="px-8 py-3 rounded-button font-medium bg-primary dark:bg-primary-600 text-primary-foreground dark:text-white hover:bg-primary/90 dark:hover:bg-primary-500 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {isSubmitting ? (
                  <><i className="fa fa-spinner fa-spin"></i> Processing...</>
                ) : currentIndex === QUESTIONS.length - 1 ? (
                  <>Submit <i className="fa fa-check"></i></>
                ) : (
                  <>Next <i className="fa fa-arrow-right"></i></>
                )}
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

// 3. Results Screen
const ResultsScreen: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as { assessment: Assessment, aiData: AIResponse } | null;

  if (!state) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background dark:bg-gray-950">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground dark:text-white mb-4">No Results Found</h2>
          <button onClick={() => navigate('/assessment')} className="px-6 py-3 bg-primary dark:bg-primary-600 text-white rounded-button">
            Start Assessment
          </button>
        </div>
      </div>
    );
  }

  const { assessment, aiData } = state;

  return (
    <div className="min-h-screen bg-background dark:bg-gray-950 pb-20">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-surface/80 dark:bg-gray-900/80 border-b border-border dark:border-gray-800 px-4 py-4">
        <div className="max-w-screen-xl mx-auto flex items-center justify-between">
          <div className="font-bold text-lg text-foreground dark:text-white flex items-center gap-2">
            <i className="fa fa-building text-primary dark:text-primary-400"></i>
            <span className="hidden sm:inline">Credit to <span className="text-warning dark:text-warning-500">Capital</span></span>
          </div>
          <div className="flex gap-2">
            <button onClick={() => navigate('/assessment')} className="px-4 py-2 text-sm font-medium text-muted-foreground dark:text-gray-300 hover:bg-muted dark:hover:bg-gray-800 rounded-md transition-colors">
              <i className="fa fa-redo mr-2"></i>Retake
            </button>
            <button className="px-4 py-2 text-sm font-medium bg-primary/10 dark:bg-primary/20 text-primary dark:text-primary-400 rounded-md hover:bg-primary/20 dark:hover:bg-primary/30 transition-colors">
              <i className="fa fa-share-alt mr-2"></i>Share
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-8 space-y-8">
        {/* Welcome Banner */}
        <div className="bg-gradient-to-r from-primary to-primary-600 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white shadow-lg animate-fade-in">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <i className="fa fa-trophy text-2xl text-warning-400"></i>
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">Assessment Complete</h1>
              <p className="text-primary-100 dark:text-gray-300">Here is your personalized financial guidance.</p>
            </div>
          </div>
        </div>

        {/* Top Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Credit Score Card */}
          <div className="bg-surface dark:bg-gray-900 rounded-card p-6 border border-border dark:border-gray-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground dark:text-white flex items-center gap-2">
                <i className="fa fa-star text-warning dark:text-warning-500"></i> Credit Score
              </h3>
              <span className="px-3 py-1 bg-primary/10 dark:bg-primary/20 text-primary dark:text-primary-400 text-xs font-bold rounded-full">
                {aiData.credit_score_analysis.category}
              </span>
            </div>
            <div className="text-4xl font-bold text-foreground dark:text-white mb-2">
              {aiData.credit_score_analysis.range}
            </div>
            <div className="w-full bg-muted dark:bg-gray-800 rounded-full h-2 mt-4">
              <div 
                className="bg-warning dark:bg-warning-500 h-2 rounded-full" 
                style={{ width: `${aiData.credit_score_analysis.gauge_percentage}%` }}
              ></div>
            </div>
          </div>

          {/* Financial Health */}
          <div className="bg-surface dark:bg-gray-900 rounded-card p-6 border border-border dark:border-gray-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground dark:text-white flex items-center gap-2">
                <i className="fa fa-heart text-error dark:text-error-500"></i> Financial Health
              </h3>
            </div>
            <div className="text-lg font-medium text-foreground dark:text-white mb-4">
              {aiData.financial_health_summary.overall_rating}
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground dark:text-gray-400">DTI Ratio</span>
                <span className="font-medium text-foreground dark:text-gray-200">{aiData.financial_health_summary.debt_to_income_ratio}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground dark:text-gray-400">Utilization</span>
                <span className="font-medium text-foreground dark:text-gray-200">{aiData.financial_health_summary.credit_utilization}</span>
              </div>
            </div>
          </div>

          {/* Funding Readiness */}
          <div className="bg-surface dark:bg-gray-900 rounded-card p-6 border border-border dark:border-gray-800 shadow-sm hover:shadow-md transition-shadow md:col-span-2 lg:col-span-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground dark:text-white flex items-center gap-2">
                <i className="fa fa-rocket text-info dark:text-info-500"></i> Funding Readiness
              </h3>
              <span className="text-2xl font-bold text-info dark:text-info-400">{aiData.funding_readiness.readiness_score}/100</span>
            </div>
            <p className="text-sm text-muted-foreground dark:text-gray-400 mb-4">
              {aiData.funding_readiness.readiness_level}
            </p>
            <div className="w-full bg-muted dark:bg-gray-800 rounded-full h-2">
              <div 
                className="bg-info dark:bg-info-500 h-2 rounded-full" 
                style={{ width: `${aiData.funding_readiness.readiness_score}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Guidance & Actions */}
          <div className="lg:col-span-2 space-y-8">
            {/* AI Guidance */}
            <div className="bg-surface dark:bg-gray-900 rounded-card p-6 md:p-8 border border-border dark:border-gray-800 shadow-sm">
              <h3 className="text-xl font-bold text-foreground dark:text-white mb-4 flex items-center gap-2">
                <i className="fa fa-lightbulb text-warning dark:text-warning-500"></i> AI Guidance
              </h3>
              <div className="p-4 bg-primary/5 dark:bg-primary/10 rounded-xl border border-primary/10 dark:border-primary/20 mb-6">
                <p className="text-foreground dark:text-gray-200 font-medium leading-relaxed">
                  {aiData.ai_guidance.primary_recommendation}
                </p>
              </div>
              <h4 className="font-semibold text-foreground dark:text-white mb-3">Additional Recommendations:</h4>
              <ul className="space-y-3">
                {aiData.ai_guidance.secondary_recommendations.map((rec, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-muted-foreground dark:text-gray-300">
                    <i className="fa fa-check-circle text-success dark:text-success-500 mt-1"></i>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Action Items */}
            <div className="bg-surface dark:bg-gray-900 rounded-card p-6 md:p-8 border border-border dark:border-gray-800 shadow-sm">
              <h3 className="text-xl font-bold text-foreground dark:text-white mb-6 flex items-center gap-2">
                <i className="fa fa-tasks text-primary dark:text-primary-400"></i> Action Plan
              </h3>
              <div className="space-y-4">
                {aiData.action_items.map((item, idx) => (
                  <div key={idx} className="flex gap-4 p-4 rounded-xl border border-border dark:border-gray-700 hover:bg-muted/50 dark:hover:bg-gray-800/50 transition-colors">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary dark:bg-primary-600 text-white flex items-center justify-center font-bold">
                      {item.priority}
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground dark:text-white mb-1">{item.action}</h4>
                      <p className="text-sm text-muted-foreground dark:text-gray-400">{item.impact}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Resources & Contact */}
          <div className="space-y-8">
            {/* Educational Resources */}
            <div className="bg-surface dark:bg-gray-900 rounded-card p-6 border border-border dark:border-gray-800 shadow-sm">
              <h3 className="text-lg font-bold text-foreground dark:text-white mb-4 flex items-center gap-2">
                <i className="fa fa-book text-info dark:text-info-500"></i> Recommended Reading
              </h3>
              <div className="space-y-4">
                {aiData.educational_resources.map((res, idx) => (
                  <a key={idx} href="#" className="block p-4 rounded-xl bg-muted/50 dark:bg-gray-800 hover:bg-muted dark:hover:bg-gray-700 transition-colors border border-transparent hover:border-border dark:hover:border-gray-600">
                    <div className="text-xs font-semibold text-primary dark:text-primary-400 mb-1 uppercase tracking-wider">{res.topic}</div>
                    <h4 className="font-medium text-foreground dark:text-white mb-2 line-clamp-2">{res.title}</h4>
                    <p className="text-xs text-muted-foreground dark:text-gray-400 line-clamp-2">{res.relevance}</p>
                  </a>
                ))}
              </div>
            </div>

            {/* Contact Card */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 dark:from-gray-800 dark:to-gray-950 rounded-card p-6 text-white shadow-lg text-center">
              <div className="w-16 h-16 mx-auto bg-white/10 rounded-full flex items-center justify-center mb-4">
                <i className="fa fa-phone text-2xl text-warning-400"></i>
              </div>
              <h3 className="text-xl font-bold mb-2">Need Expert Help?</h3>
              <p className="text-gray-300 text-sm mb-6">Speak with our financial advisors to accelerate your funding readiness.</p>
              <a 
                href="https://wa.me/12056905652" 
                target="_blank" 
                rel="noopener noreferrer"
                className="block w-full py-3 px-4 bg-warning-500 hover:bg-warning-600 text-gray-900 font-bold rounded-button transition-colors"
              >
                Contact Support
              </a>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
};

// --- Main App Component ---
export default function App() {
  // Analytics initialization (runs once)
  useEffect(() => {
    try {
      analyticsService.initialize();
      // Optionally track first page view:
      // analyticsService.trackPageView?.(window.location.pathname);
      // console.log('Analytics initialized');
    } catch (error) {
      console.error('Failed to initialize analytics:', error);
    }
  }, []);

  const [userId, setUserId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initUser = async () => {
      try {
        const storedId = localStorage.getItem('user_id');
        if (storedId) {
          setUserId(storedId);
        } else {
          const user = await api.createUser();
          localStorage.setItem('user_id', user.id);
          setUserId(user.id);
        }
      } catch (error) {
        console.error('Failed to initialize user:', error);
      } finally {
        setIsLoading(false);
      }
    };
    initUser();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background dark:bg-gray-950">
        <i className="fa fa-spinner fa-spin text-4xl text-primary dark:text-primary-500"></i>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<SplashScreen />} />
      <Route path="/assessment" element={<AssessmentScreen userId={userId!} />} />
      <Route path="/results" element={<ResultsScreen />} />
      <Route path="*" element={<SplashScreen />} />
    </Routes>
  );
}